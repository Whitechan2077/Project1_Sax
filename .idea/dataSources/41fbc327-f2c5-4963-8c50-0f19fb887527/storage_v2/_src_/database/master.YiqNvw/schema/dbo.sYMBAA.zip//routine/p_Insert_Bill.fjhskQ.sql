CREATE   PROCEDURE p_Insert_Bill
@ngayLap date,@sdt varchar(10)
AS
	BEGIN
	IF(@ngayLap is null or @sdt is null) print'thieu du lieu'
	else
			INSERT INTO hoaDon(ngayLap,sdt)
		VALUES(@ngayLap,@sdt)
	END
go

