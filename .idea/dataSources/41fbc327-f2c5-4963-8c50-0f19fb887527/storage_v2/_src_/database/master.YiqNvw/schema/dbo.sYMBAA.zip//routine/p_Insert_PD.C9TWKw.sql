CREATE   PROCEDURE p_Insert_PD
@tenSanPham nvarchar(70),@giaHienHanh int ,@soLuongTonKho int 
AS
	BEGIN
	IF(@tenSanPham is null or @giaHienHanh is null or @soLuongTonKho is null) print 'thieu du lieu'
	ELSE
	BEGIN
			INSERT INTO sanPham(tenSanPham,giaHienHanh,soLuongTonKho)
		VALUES(@tenSanPham ,@giaHienHanh  ,@soLuongTonKho)
	END
	END
go

