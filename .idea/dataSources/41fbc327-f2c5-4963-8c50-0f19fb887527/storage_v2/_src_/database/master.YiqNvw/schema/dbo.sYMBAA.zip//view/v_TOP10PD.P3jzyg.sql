CREATE   VIEW v_TOP10PD
AS
	SELECT TOP 10 sanPham.maSanPham,sanPham.tenSanPham,SUM(hoaDonChitiet.soLuongMua) AS 'SoLuongMua',YEAR(hoaDon.ngayLap) AS 'nam',MONTH(hoaDon.ngayLap) AS 'Thang'
		FROM hoaDon JOIN hoaDonChitiet ON hoaDon.maHoaDon = hoaDonChitiet.maHoaDon JOIN  sanPham 
			on hoaDonChitiet.maSanPham = sanPham.maSanPham
		GROUP BY sanPham.tenSanPham,sanPham.maSanPham,hoaDon.ngayLap
		ORDER BY SoLuongMua DESC 
go

