CREATE PROCEDURE sp_getUser
	@id int
	AS
		BEGIN
		IF @id = 0 SELECT maNguoiDung,tenNguoiDung,CASE
					WHEN gioiTinh =  0 THEN 'Nam'
					WHEN gioiTinh = 1 THEN N'Nữ'
					END AS [Gioi tinh]
					,
					'0'+CONVERT(varchar,FORMAT(CONVERT(int,sdt),'0##,##')) AS [sdt],
					diaChi,quan,email  FROM Nguoi_Dung
		ELSE 
			SELECT maNguoiDung,tenNguoiDung,CASE
					WHEN gioiTinh =  0 THEN 'Nam'
					WHEN gioiTinh = 1 THEN N'Nữ'
					END AS [Gioi tinh]
					,
					'0'+CONVERT(varchar,FORMAT(CONVERT(int,sdt),'0##,##')) AS [sdt],
					diaChi,quan,email
			FROM Nguoi_Dung
			WHERE maNguoiDung = @id;
		END
go

