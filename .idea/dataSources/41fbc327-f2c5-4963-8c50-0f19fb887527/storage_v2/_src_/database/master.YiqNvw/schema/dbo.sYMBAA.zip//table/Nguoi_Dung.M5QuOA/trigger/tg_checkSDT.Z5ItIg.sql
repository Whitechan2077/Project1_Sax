CREATE TRIGGER tg_checkSDT ON Nguoi_Dung
	FOR INSERT
	AS
		BEGIN
		IF(SELECT sdt FROM inserted) like '0%' AND (SELECT LEN(sdt) FROM inserted) = 10
			PRINT 'INSERT thanh cong'
		ELSE 
			BEGIN
				Print'Loi sdt sai'
				ROLLBACK TRANSACTION
			END
		END
go

