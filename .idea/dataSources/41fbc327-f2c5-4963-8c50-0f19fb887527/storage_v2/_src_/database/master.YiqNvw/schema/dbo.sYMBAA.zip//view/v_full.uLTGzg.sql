CREATE VIEW v_full
AS
	SELECT sanPham.maSanPham,hoaDonChitiet.maHoaDon,hoaDonChitiet.soLuongMua,hoaDonChitiet.giaMua,
			(hoaDonChitiet.soLuongMua*hoaDonChitiet.giaMua)AS 'thanh tien'
		FROM sanPham JOIN hoaDonChitiet ON sanPham.maSanPham = hoaDonChitiet.maSanPham
go

