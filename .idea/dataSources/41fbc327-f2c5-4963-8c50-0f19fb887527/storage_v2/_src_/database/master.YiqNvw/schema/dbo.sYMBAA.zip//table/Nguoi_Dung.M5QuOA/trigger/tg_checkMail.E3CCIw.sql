CREATE TRIGGER tg_checkMail ON Nguoi_Dung
	FOR INSERT
	AS
		BEGIN
		IF(SELECT email FROM inserted) like '%@gmail.com' PRINT 'INSERT thanh cong'
		ELSE 
			BEGIN
				Print'Loi'
				ROLLBACK TRANSACTION
			END
		END
go

