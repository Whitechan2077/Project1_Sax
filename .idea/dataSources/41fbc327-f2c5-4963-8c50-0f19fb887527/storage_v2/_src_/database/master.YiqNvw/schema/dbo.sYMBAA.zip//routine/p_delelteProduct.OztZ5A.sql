CREATE PROCEDURE p_delelteProduct
@id int
AS
	BEGIN
		delete FROM hoaDonChitiet
			WHERE maSanPham = @id
		DELETE FROM sanPham FROM sanPham 
			WHERE maSanPham = @id
	END
go

