CREATE   PROCEDURE p_Insert_Bill_Detail
@maSanPham int,@maHoaDon int,@soLuongMua int,@giaMua int
AS
	BEGIN
	if(@maSanPham is null or @maHoaDon is null or @soLuongMua is null or @giaMua is null) print 'thieu du lieu'
	ELSE
		INSERT INTO hoaDonChitiet(maSanPham,maHoaDon,soLuongMua,giaMua )
		VALUES(@maSanPham,@maHoaDon,@soLuongMua,@giaMua)
	END
go

