Create   procedure p_updateLecture
	@tenGiangVien nvarchar(25),@idNganh  int,@sdt varchar(10),@email varchar(100),@gioiTinh bit,@hinhAnh VARBINARY(MAX),@diaChi nvarchar(80),@idGiangVien int
AS
	BEGIN
		UPDATE Giang_Vien SET tenGiangVien=@tenGiangVien,idNganh=@idNganh,sdt=@sdt,email=@email,gioiTinh=@gioiTinh,hinhAnh=@hinhAnh,diaChi=@diaChi
			WHERE idGiangVien =@idGiangVien
	END	
go

