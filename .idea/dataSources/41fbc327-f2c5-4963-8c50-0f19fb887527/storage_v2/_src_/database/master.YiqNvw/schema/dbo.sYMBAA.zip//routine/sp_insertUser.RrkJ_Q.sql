CREATE PROCEDURE sp_insertUser
	@tenNguoiDung nvarchar(30),@gioiTinh tinyint,
	@sdt nvarchar(10),@diaChi nvarchar(50),
	@quan nvarchar(15),@email nvarchar(50)
AS
	BEGIN
	INSERT INTO Nguoi_Dung(tenNguoiDung,gioiTinh,sdt,diaChi,quan,email) 
		VALUES(@tenNguoiDung,@gioiTinh,@sdt,@diaChi,@quan,@email);
	END
go

